GDC ZIAM - Local Working Version Restore Guide

IMPORTANT: Pehle database file db.sqlite3 ki backup copy rakhein. Is pack mein database shamil nahi hai.

Aapne jo settings.py ka code share kiya tha, woh original local-development settings ke barabar hai. Agar aapki active project ki config/settings.py pehle se usi code jaisi hai, to settings.py replace karne ki zaroorat nahi. Website ka "site can't be reached" error aksar tab aata hai jab Django server Ctrl+C se ruk gaya ho.

SIRF AGAR aapne active project mein naya settings.py copy karke purana badal diya hai:
1. Apne ACTIVE project folder mein jayein - wahi folder jisme manage.py, db.sqlite3 aur .venv hain.
2. Us folder ke config subfolder mein purani settings.py ka backup bana lein.
3. Is pack ke config/settings.py ko us active folder ke config/settings.py se replace karein.
4. db.sqlite3 ko kabhi replace/delete na karein.

Website ko dobara chalane ka sabse asaan tareeqa:
1. Active project folder mein run_windows.bat par double-click karein.
2. Black window khuli rehne dein.
3. Chrome mein http://127.0.0.1:8000/ kholein.

Agar run_windows.bat error de, to error ka screenshot bhejein. Poora purana project ZIP extract karke active folder ke upar overwrite na karein, kyunki isse database/demo accounts replace ho sakte hain.

Production security warnings (check --deploy) ka matlab yeh nahi ke local code automatically kharab ho gaya. In settings ko final domain aur HTTPS hosting ready hone par set karna chahiye.
